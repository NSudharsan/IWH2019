package com.example.demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RouteController {

	private static final Logger logger = Logger.getLogger(RouteController.class);
	/*
	 * @Autowired private ResourceLoader resourceLoader;
	 */

	@RequestMapping(method = RequestMethod.GET, value = "/testing")
	String test() {
		logger.info("Service is up");
		return "Service is up :-)";
	}

	@RequestMapping(path = "/getPath", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity getPathFile() throws FileNotFoundException {
		File file = null;
		try {
			file = ResourceUtils.getFile("classpath:samplePath.json");
			logger.info("File found :" + file.exists());// File is found
		} catch (FileNotFoundException e) {
			e.printStackTrace();

		}
		// Read File Content
		String content;
		try {
			content = new String(Files.readAllBytes(file.toPath()));
			System.out.println(content);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			content = "Error parsing File";
		}
		return new ResponseEntity<>(content, HttpStatus.OK);

	}

	@RequestMapping(path = "/getPath/{start}/{end}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity getPathFile(@PathVariable("start") String startPoint, @PathVariable("end") String destPoint)
			throws IOException {

		File file = ResourceUtils.getFile("classpath:PathToVeggies.json");

		String content = new String(Files.readAllBytes(file.toPath()));
		logger.info("Computing Direct Path"+content);
		return new ResponseEntity<>(content, HttpStatus.OK);
	}

	@RequestMapping(path = "/getAlternatePath/{start}/{end}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity getAlternatePathFile(@PathVariable("start") String startPoint, @PathVariable("end") String destPoint)
			throws IOException {

		File file = ResourceUtils.getFile("classpath:AlternatePathToVeggies.json");

		String content = new String(Files.readAllBytes(file.toPath()));
		logger.info("Computing Alternate Path"+content);
		return new ResponseEntity<>(content, HttpStatus.OK);
	}
	
}
