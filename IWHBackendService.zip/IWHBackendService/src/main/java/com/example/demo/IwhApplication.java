package com.example.demo;

import org.apache.log4j.BasicConfigurator;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication(scanBasePackages = {"com.example"})
public class IwhApplication {

    public static void main(String[] args) {
    	BasicConfigurator.configure();//to configure log4j
        SpringApplication.run(IwhApplication.class, args);
    }
    }

